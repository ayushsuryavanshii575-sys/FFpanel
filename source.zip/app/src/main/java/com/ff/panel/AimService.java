package com.ff.panel;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;
import java.util.Random;

public class AimService extends AccessibilityService {
    public static AimService instance = null;
    public static float aimStrength = 0.5f;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    public void aimTo(float targetX, float targetY) {
        if (instance == null) return;
        float centerX = getResources().getDisplayMetrics().widthPixels / 2f;
        float centerY = getResources().getDisplayMetrics().heightPixels / 2f;
        Random random = new Random();
        float jitterX = random.nextInt(11) - 5;
        float jitterY = random.nextInt(11) - 5;
        float finalX = centerX + (targetX - centerX) * aimStrength + jitterX;
        float finalY = centerY + (targetY - centerY) * aimStrength + jitterY;

        Path path = new Path();
        path.moveTo(finalX, finalY);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 30));
        dispatchGesture(builder.build(), null, null);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override
    public void onInterrupt() {}
}