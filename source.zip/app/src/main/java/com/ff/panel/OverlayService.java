package com.ff.panel;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.os.IBinder;
import android.view.View;
import android.view.WindowManager;
import java.util.ArrayList;
import java.util.List;

public class OverlayService extends Service {
    public static OverlayService instance;
    private View overlayView;
    private List<RectF> targetBoxes = new ArrayList<>();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        instance = this;
        WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        overlayView = new ESPView(this);
        windowManager.addView(overlayView, params);
        return START_STICKY;
    }

    public static void updateTargets(List<RectF> boxes) {
        if (instance != null) {
            instance.targetBoxes = boxes;
            if (instance.overlayView != null) instance.overlayView.postInvalidate();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (overlayView != null) {
            WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            windowManager.removeView(overlayView);
        }
        instance = null;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    class ESPView extends View {
        Paint boxPaint; Paint textPaint;
        public ESPView(Context context) {
            super(context);
            boxPaint = new Paint(); boxPaint.setColor(Color.RED); boxPaint.setStyle(Paint.Style.STROKE); boxPaint.setStrokeWidth(5f); boxPaint.setAntiAlias(true);
            textPaint = new Paint(); textPaint.setColor(Color.GREEN); textPaint.setTextSize(40f); textPaint.setAntiAlias(true);
        }
        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int cx = getWidth() / 2; int cy = getHeight() / 2;
            for (RectF box : targetBoxes) {
                canvas.drawRect(box, boxPaint);
                float dx = box.centerX() - cx; float dy = box.centerY() - cy;
                float dist = (float) Math.sqrt(dx*dx + dy*dy);
                canvas.drawText((int)(dist / 10) + "m", box.left, box.top - 10, textPaint);
                if (dist < 300 && AimService.instance != null) {
                    AimService.instance.aimTo(box.centerX(), box.centerY());
                }
            }
        }
    }
}