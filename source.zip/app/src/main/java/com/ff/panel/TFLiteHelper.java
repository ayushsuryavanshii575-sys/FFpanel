package com.ff.panel;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.RectF;
import java.util.ArrayList;
import java.util.List;

public class TFLiteHelper {
    // फिलहाल यह एक खाली हेल्पर है। जब हमारे पास AI मॉडल होगा, तब हम इसमें कोड डालेंगे।
    public TFLiteHelper(Context context) {
    }

    public List<RectF> detectObjects(Bitmap bitmap) {
        List<RectF> list = new ArrayList<>();
        // अभी यह खाली लिस्ट भेजेगा, लेकिन ऐप क्रैश नहीं होगा।
        return list;
    }

    public void close() {
    }
}